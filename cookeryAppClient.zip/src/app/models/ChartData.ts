export class ChartData {
    public title: string;
    // xAxis: Object;
    // yAxis: Object;
    public xAxis: Object[];
    public yAxis: Object[];
}