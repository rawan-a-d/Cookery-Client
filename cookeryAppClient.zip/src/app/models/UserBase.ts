export class UserBase {
    constructor(public id: number, public name: string, public email: string){}
}