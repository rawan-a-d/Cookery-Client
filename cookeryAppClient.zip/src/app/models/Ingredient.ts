export class Ingredient {
    id: number;
    ingredient: string;
    amount: number;
}